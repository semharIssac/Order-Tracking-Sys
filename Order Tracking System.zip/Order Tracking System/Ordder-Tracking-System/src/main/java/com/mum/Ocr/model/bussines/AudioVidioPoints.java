package com.mum.Ocr.model.bussines;

import java.io.Serializable;

public class AudioVidioPoints extends ACompPoints  {
	
	private final double points=0.5;
	public double getPoints() {
		return points;
	}

}
