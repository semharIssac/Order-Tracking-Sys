package com.mum.Ocr.model.bussines;

public abstract class ACompPoints implements ICompPoints {
	

	public abstract double getPoints();
}
