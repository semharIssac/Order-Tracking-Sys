package com.mum.Ocr.model.bussines;

public interface ICustomer {
	public String  getCreditRating();
	public double getPoints();
	public void setPoints(double points);
}
